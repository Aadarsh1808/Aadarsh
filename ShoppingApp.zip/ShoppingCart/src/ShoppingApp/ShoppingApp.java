package ShoppingApp;

import java.util.LinkedList;

public class ShoppingApp {
	public static void main(String[] args) {
        
        ShoppingCart cart = new ShoppingCart();
        cart.addItem("Apple");
        cart.addItem("Banana");
        cart.viewItems();
        cart.removeItem("Apple");
        cart.viewItems();
        
        PurchaseHistory history = new PurchaseHistory();
        history.saveCart(new LinkedList<>(cart.cart)); 
        cart.addItem("Cherry");
        history.viewHistory();
        cart.viewItems();
        cart.cart = history.undoLastPurchase(); 
        cart.viewItems();

        
        CustomerService service = new CustomerService();
        service.addRequest("Issue with order #123");
        service.addRequest("Refund request for order #156");
        service.viewRequests();
        service.processRequest();
        service.viewRequests();
    }
}

