package ShoppingApp;

import java.util.LinkedList;

class ShoppingCart {
	 LinkedList<String> cart;

	    public ShoppingCart() {
	        cart = new LinkedList<>();
	    }

	    public void addItem(String item) {
	        cart.add(item);
	    }

	    public void removeItem(String item) {
	        cart.remove(item);
	    }

	    public void viewItems() {
	        System.out.println("Items in cart: " + cart);
	    }
	}

