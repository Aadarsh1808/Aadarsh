package ShoppingApp;

import java.util.LinkedList;
import java.util.Queue;

class CustomerService {
	private Queue<String> requests;

    public CustomerService() {
        requests = new LinkedList<>();
    }

    public void addRequest(String request) {
        requests.add(request);
    }

    public void processRequest() {
        if (!requests.isEmpty()) {
            String request = requests.poll();
            System.out.println("Processed request: " + request);
        } else {
            System.out.println("No requests to process.");
        }
    }

    public void viewRequests() {
        System.out.println("Pending Requests: " + requests);
    }
}

